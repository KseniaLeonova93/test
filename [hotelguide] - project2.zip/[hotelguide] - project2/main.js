import './components/animation-city.js';
import './components/slider.js';
import './components/scroll-up.js';
import './components/scroll-down.js';
import './components/current-year.js';