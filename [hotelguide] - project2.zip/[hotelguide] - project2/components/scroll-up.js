const scrollButtonUp = document.getElementById("button-scroll-up");
const sectionCitiesInformation = document.getElementById("cities-information");

window.addEventListener("scroll", function () {
  let sectionPosition = sectionCitiesInformation.getBoundingClientRect().top;
  scrollButtonUp.style.opacity = sectionPosition <= 0 ? "1" : "0";
});

scrollButtonUp.addEventListener("click", function (e) {
  e.preventDefault();

  const sectionPosition = sectionCitiesInformation.getBoundingClientRect().top;
  const startingY = window.scrollY;
  const targetY = startingY + sectionPosition;
  const duration = 1000; // Длительность анимации в миллисекундах
  const framesPerSecond = 60; // Частота кадров

  const frameDuration = 1000 / framesPerSecond;
  const totalFrames = Math.ceil(duration / frameDuration);

  function scroll() {
    const currentTime = performance.now();
    const elapsed = currentTime - startTime;
    if (elapsed < duration) {
      const progress = Math.min(1, elapsed / duration);
      const easedProgress = easeInOutQuad(progress);
      const newY = startingY + sectionPosition * easedProgress;
      window.scrollTo(0, newY);
      requestAnimationFrame(scroll);
    } else {
      window.scrollTo(0, targetY);
    }
  }

  function easeInOutQuad(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  const startTime = performance.now();
  requestAnimationFrame(scroll);
});
