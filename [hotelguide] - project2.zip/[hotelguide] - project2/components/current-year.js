const currentYear = new Date().getFullYear();
document.getElementById("currentYear").innerText = currentYear;