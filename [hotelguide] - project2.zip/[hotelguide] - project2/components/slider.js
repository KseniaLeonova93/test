import { fadeIn } from './animation-city.js';

let mySwiper = new Swiper('.swiper', {
  slidesPerView: 3,
  centeredSlides: true,
  loop: true,
  loopAdditionalSlides: 4,
  autoplay: {
    delay: 10000,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});

mySwiper.on('slideChange', () => {
  const activeSlideIndex = mySwiper.realIndex;
  const activeSlide = document.querySelector(`.swiper-slide[data-swiper-slide-index="${activeSlideIndex}"]`);
  const activeCountry = activeSlide.getAttribute('data-country');
  const cities = document.querySelectorAll('.city');

  cities.forEach(city => {
    const relatedCountry = city.dataset.relatesCountry;

    if (relatedCountry === activeCountry) {
      fadeIn(city);
    } else {
      city.style.display = 'none';
    }
  });
});


mySwiper.on('click', function (event) {
  const clickedSlideIndex = event.clickedIndex;
  mySwiper.slideToClickedSlide(clickedSlideIndex);
});


