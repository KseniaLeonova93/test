    const scrollButton = document.getElementById("button-scroll-down");
  const sectionCitiesInformation = document.getElementById("cities-information");

  scrollButton.addEventListener("click", function(e) {
    e.preventDefault();

    const sectionCitiesInformationPosition = sectionCitiesInformation.getBoundingClientRect().top;
    const startingY = window.scrollY;
    const targetY = startingY + sectionCitiesInformationPosition;
    const duration = 1000; // Длительность анимации в миллисекундах
    const framesPerSecond = 60; // Частота кадров

    const frameDuration = 1000 / framesPerSecond;
    const totalFrames = Math.ceil(duration / frameDuration);

    function scroll() {
      const currentTime = performance.now();
      const elapsed = currentTime - startTime;
      if (elapsed < duration) {
        const progress = Math.min(1, elapsed / duration);
        const easedProgress = easeInOutQuad(progress);
        const newY = startingY + sectionCitiesInformationPosition * easedProgress;
        window.scrollTo(0, newY);
        requestAnimationFrame(scroll);
      } else {
        window.scrollTo(0, targetY);
      }
    }

    function easeInOutQuad(t) {
      return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    }

    const startTime = performance.now();
    requestAnimationFrame(scroll);
  });
